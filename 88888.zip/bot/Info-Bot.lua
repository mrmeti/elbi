bot_token = "5034071891:AAEshtJVw83BXEhhwdoL6GpVc-fFGk3GeVE" -- توکن رباتُ
channel_username = '@Metiwz_team' -- آیدی کانال
channel_inline = 'Metiwz_Team' -- آیدی کانال بدون @
sudo_username = '@Metiwz' -- آیدی سازنده ربات
gp_sudo = 1900060993 -- آیدی سودو اصلی
SUDO = 1900060993 -- آیدی سودو اصلی
BotMaTaDoR_id = 1219147672 --آیدی ربات cli
BotMaTaDoR_idapi = 5034071891 --آیدی ربات api
RedisIndex = '1' -- شماره ردیس
EndPm = " ツ
--[ Open by @EarthTM & @Infosplus ]--